# Dienstplan lokal weiterverwenden

Stand: 16. Oktober 2026. Der vollständige Programmcode steckt in **Wochenplan.html**.

## Start

1. Den gesamten Ordner **Dienstplan-Lokal** entpacken.
2. **Wochenplan.html** im Browser öffnen.
3. Oben **Normalbetrieb** oder **Ferien** wählen.
4. Viertelstunden im Plan markieren und anschließend **BZ**, **VZ**, **BZ/VZ**, **Pause** oder **Leeren** wählen.

Es gibt keinen Build-Schritt, keinen Account und keine nachzuladenden Bibliotheken. Die Bedienung steht ausführlich in [Hinweise.md](Hinweise.md).

## Eigene Daten mitnehmen

**Vor dem Wechsel im bisherigen Browser „Sicherung“ anklicken.** Diese JSON-Datei enthält die eigenen Normal- und Ferienzeiten. Die Datei zusätzlich in diesen Ordner kopieren und im neuen Browser über **Mehr → Datei öffnen** laden.

Das Paket enthält als Ausgangsdaten den ursprünglichen Excel-Normalplan mit 19 Personen und 331 Zeitblöcken sowie einen leeren Ferienplan. Eigene nachträgliche Eingaben im Browser sind nicht automatisch Bestandteil dieses Downloads. Browser-Speicher und Zwischenablage werden nicht zwischen Geräten, Browsern oder unterschiedlichen lokalen Adressen übertragen.

**Dienstplan_2027.json** ist die mitgelieferte Ausgangssicherung, keine aus dem Browser des Nutzers ausgelesene persönliche Sicherung. Sie muss beim ersten Start nicht extra geladen werden; dieselben Normalzeiten sind schon in der HTML-Datei eingebettet.

## In einen lokalen Chat umziehen

Dem lokalen Chat Zugriff auf diesen Ordner geben und zuerst [UEBERGABE.md](UEBERGABE.md) lesen lassen. Dort stehen Anforderungen, Entscheidungen, Rechenregeln, aktueller Stand, Aufbau des Codes, Prüfungen und bekannte Grenzen. Am Ende steht ein direkt verwendbarer Starttext für den neuen Chat.

## Falls direktes Öffnen nicht funktioniert

Ein Terminal in diesem Ordner öffnen und einen lokalen Server starten:

```sh
python -m http.server 8001 --bind 127.0.0.1
```

Je nach Installation heißt der Befehl `python3`; unter Windows ist auch `py -m http.server 8001 --bind 127.0.0.1` möglich. Danach im eigenen Browser **http://127.0.0.1:8001/Wochenplan.html** öffnen. Dieser Server bleibt nur auf dem eigenen Rechner erreichbar. Mit Strg+C beenden.

Die vorherige Browserprüfung wurde über einen lokalen HTTP-Server durchgeführt; direktes Öffnen per `file://` war in der Cloud-Testumgebung durch deren Browserrichtlinie gesperrt. Wird die Startadresse gewechselt, die eigene JSON-Sicherung erneut laden.

## Inhalt

| Datei | Zweck |
|---|---|
| `Wochenplan.html` | Vollständige Anwendung einschließlich Quellcode, Excel-Exportvorlage und ZIP-Bibliothek |
| `Dienstplan_2027.json` | Ausgangsdaten: Original-Normalplan und leerer Ferienplan |
| `Hinweise.md` | Bedienung, Berechnungen, Export und bisherige Prüfergebnisse |
| `UEBERGABE.md` | Zusammenfassung und technischer Kontext für den neuen lokalen Chat |
| `fflate-LICENSE.txt` | Lizenz der eingebetteten Bibliothek fflate |
| `Vorlagen/BLANKO Korreg. Vorlage.xlsx` | Ursprünglich hochgeladene leere Vorlage |
| `Vorlagen/2027 Entwurf Dienstplan_GTS 20MA-15min.xlsx` | Ursprünglich hochgeladener ausgefüllter Plan, Grundlage der Berechnungen und des Exports |
| `SHA256SUMS.txt` | Prüfsummen der mitgelieferten Dateien |

**Sicherung** speichert beide Planarten. **Excel exportieren** exportiert nur die gerade gewählte Planart; für Normalbetrieb und Ferien jeweils einmal exportieren.
