# Dienstplan – Viertelstunden wie in Excel

ZIP entpacken und **Wochenplan.html** öffnen. Die Anwendung enthält die hochgeladene Excel-Vorlage und den ausgefüllten Dienstplan. Sie benötigt keine Installation, keinen Account und keine externen Bibliotheken aus dem Internet.

## Zeitfelder markieren und gemeinsam ausfüllen

Die Startansicht zeigt den Tagesplan mit allen Mitarbeitenden nebeneinander. Jede Spalte besteht aus **56 einzelnen Viertelstundenfeldern von 06:00 bis 20:00**. Auch lange BZ-Zeiträume sind in dieser Ansicht als einzelne Kästchen dargestellt.

1. Oben **Normalbetrieb** oder **Ferien** und anschließend **Montag bis Freitag** wählen.
2. Über ein oder mehrere Zeitfelder ziehen. Die blaue Markierung kann mehrere Personen gleichzeitig umfassen. Ein einzelner Klick markiert ein Viertelstundenfeld. Das Markieren allein verändert keine Zeiten.
3. **BZ**, **VZ**, **BZ/VZ** oder **Pause** anklicken, um genau die Auswahl zu füllen. **Leeren** entfernt genau den markierten Bereich.
4. Bei Bedarf **Von** und **Bis** direkt als Stunden:Minuten ändern, zum Beispiel **08:31** und **09:03**. Danach eine Art oder Leeren wählen. Dadurch sind auch Auswahlgrenzen außerhalb des Viertelstundenrasters möglich.

**Beispiel:** BZ von 08:00 bis 16:00. Die Felder 12:00 und 12:15 markieren und **Pause** wählen. Ergebnis: **BZ 08:00–12:00 · Pause 12:00–12:30 · BZ 12:30–16:00**. Die Anwendung teilt den bisherigen BZ-Block automatisch. Ein ursprüngliches Ende **16:03** bleibt ebenfalls erhalten. Außerhalb der ausgewählten Minuten werden weder Kategorien noch Zeiten oder Bezeichnungen verändert. Direkt aneinandergrenzende gleichartige Abschnitte mit derselben Bezeichnung können intern zusammengefasst werden; in der Ansicht bleiben die einzelnen Viertelstunden sichtbar.

Die Felder **Von/Bis** zeigen die Auswahl, noch keine bestätigte Planänderung. Ungültige Zeiten werden beim Anwenden abgewiesen, ohne einen Teil der Auswahl zu ändern. **Aufheben** oder Escape entfernt die Markierung.

Ein **Doppelklick auf ein belegtes Kästchen** öffnet zusätzlich den genauen bisherigen Zeitraum. Für Änderungen an einzelnen Viertelstunden reicht das normale Markieren und Füllen; der gesamte Zeitraum muss dafür nicht geöffnet werden.

Farben: **BZ** türkis, **VZ** violett, **BZ/VZ** orange, **Pause** grau. BZ/VZ zählt vollständig als BZ; eine zusätzliche Aufteilungszeit gibt es nicht. Pausen zählen nicht zur Arbeitszeit.

## Normalbetrieb und Ferien

Jede Person hat zwei getrennte Montag-bis-Freitag-Pläne. **Normalbetrieb** enthält zunächst die Zeiten aus der hochgeladenen Excel-Datei; **Ferien** startet leer. Der Schalter oben wechselt die Planart für die gesamte Teamansicht. Wochenübersicht und Personenwoche folgen derselben Auswahl.

**Namen und Vertragsstunden sind gemeinsam. Zeiten, Pausen, Ist-Stunden, Differenzen und Besetzung gehören jeweils zum ausgewählten Plan.** Stunden aus Normal- und Ferienplan werden nicht addiert. In beiden Planarten gelten dieselben Vertragsstunden und die bestätigte Vollzeitbasis von 39 Stunden.

Unter **Mitarbeitende** kann die ausgewählte Person ihren jeweils anderen Plan mit **Normalplan/Ferienplan für diese Person übernehmen** als Ausgangspunkt kopieren. Erst die Rückfrage bestätigen; danach sind die beiden Pläne weiterhin unabhängig bearbeitbar. **Rückgängig** stellt den vorherigen Zustand wieder her.

**Sicherung** speichert immer **beide Pläne gemeinsam** in einer JSON-Datei, einschließlich der ausgewählten Planart. **Mehr → Datei öffnen** lädt eine solche Sicherung. Vorhandene ältere Sicherungen werden als Normalplan übernommen und erhalten einen leeren Ferienplan. Das Laden ersetzt beide Pläne nach einer entsprechenden Rückfrage. Browserdaten bleiben beim Öffnen der HTML-Datei erhalten und werden automatisch auf das erweiterte Format übernommen.

**Excel exportieren** exportiert den gerade ausgewählten Plan in die Originalvorlage. Dateiname und Hinweis in den Tagesblättern kennzeichnen **Normalbetrieb** beziehungsweise **Ferien**. Für beide Planarten zwei Exporte erstellen. Die JSON-Sicherung enthält immer beide Planarten.

**Mehr → Ausgefüllten Plan laden** setzt nach der Rückfrage beide Pläne zurück: Normalbetrieb auf die Original-Excel-Zeiten, Ferien leer. Eigene Zeiten vorher über Sicherung speichern.

## Kopieren, Einfügen und Rückgängig

Im Modus **Zeitfelder ausfüllen**:

1. Zeitfelder über eine oder mehrere Personen markieren und **Kopieren** wählen.
2. Das linke obere Zielfeld markieren und **Einfügen** wählen.
3. Die gesamte kopierte Fläche wird eingefügt: genaue Minuten, Kategorien, Bezeichnungen und auch freie Lücken. Vorhandene Zeiten innerhalb der Zielfläche werden dadurch ersetzt. Zeiten außerhalb bleiben erhalten.

Die gewählte Zielmarkierung setzt den Anfang; Größe und Dauer kommen aus der Kopie. Passt die ganze Kopie nicht in die vorhandenen Personen/Tage oder den Zeitbereich, wird nichts eingefügt. Die Zwischenablage gilt innerhalb der laufenden Anwendung und kann auch zwischen Normalbetrieb und Ferien verwendet werden. Sie ist kein allgemeiner Import beliebiger Excel-Zellen.

Tastatur bei markierter Auswahl außerhalb von Eingabefeldern: **B** für BZ, **V** für VZ, **M** für BZ/VZ, **P** für Pause, **Entf/Rücktaste** zum Leeren. Pfeiltasten verschieben die Auswahl um eine Person/einen Tag oder 15 Minuten. **Strg/Cmd + C / V** kopiert/fügt die Zeitfelder ein. In Eingabefeldern bleiben normale Textfunktionen erhalten.

**Rückgängig** und **Wiederholen** beziehungsweise Strg/Cmd + Z und Strg/Cmd + Umschalt + Z / Y verwalten bis zu 30 Bearbeitungsschritte im laufenden Fenster. Eine gemeinsame Bereichsänderung ist genau ein Schritt. Auch das Entfernen einer Person, das Kopieren des anderen Plans und ein Planartenwechsel sind rückgängig möglich. Nach Neuladen bleibt der gespeicherte Plan erhalten, die Bearbeitungshistorie beginnt neu.

## Ansichten und Mitarbeitende

- **Tagesplan · alle:** Startansicht wie die Tagesblätter in Excel. Personenspalten, Zeitachse und einzelne Viertelstundenfelder. Rechts stehen **BZ+VZ**, **BZ** und **VZ** für alle gleichzeitig eingeteilten Personen. Bei Wechseln innerhalb einer Viertelstunde erscheint zum Beispiel **2–3**. Die Besetzung und Zeitachse bleiben beim seitlichen Scrollen sichtbar; Namen bleiben beim vertikalen Scrollen im Plan sichtbar.
- **Wochenübersicht · alle:** Personen als Zeilen, Montag bis Freitag als Spalten. Exakte Zeiträume stehen in jedem Tagesfeld. **+ Zeitraum** öffnet die Eingabe für genau diese Person und diesen Tag. Zeiträume lassen sich unverändert in andere Tagesfelder ziehen. Personen- und Tagesüberschriften bleiben beim Scrollen sichtbar.
- **Personenwoche:** Eine ausgewählte Person mit Montag bis Freitag nebeneinander. Im Modus Zeitfelder ausfüllen können mehrere Tage gemeinsam markiert und gefüllt werden.

Die Auswahl rechts neben den Tagestasten wechselt die Ansicht. Eine Tagestaste kehrt zum gemeinsamen Tagesplan zurück. Die Zeit- und Team-Bilanzen sowie Hilfe lassen sich unter dem Plan aufklappen.

**Mitarbeitende** oder ein Name über einer Personenspalte öffnet die Verwaltung. Eine Person auswählen, um Namen oder Vertragsstunden zu ändern. **Person entfernen** entfernt nach der Rückfrage die Person mit **beiden Dienstplänen**. Rückgängig stellt Namen, Vertrag und sämtliche Zeiten wieder her. Auch die letzte Person kann entfernt werden; der leere Plan bietet Hinzufügen und Rückgängig. Bis zu 20 Personen sind möglich.

## Ganze Blöcke verschieben

Die Bedienungsauswahl **Blöcke verschieben** bietet weiterhin die Kalenderbedienung: Art wählen und einen neuen Zeitraum aufziehen oder einen Baustein direkt aus der Werkzeugleiste auf den Plan ziehen. Aufziehen richtet neue Zeiträume am Viertelstundenraster aus. Ein gezogener Baustein beginnt mit 15 Minuten.

Bestehende Blöcke am Textbereich verschieben oder an den mittleren Griffen verlängern/kürzen. Ein Klick öffnet genaue Zeiten. Ziehen und Pfeiltasten arbeiten in 1-Minuten-Schritten; Umschalt + Pfeil auf/ab arbeitet in 15-Minuten-Schritten. Überschneidungen werden abgelehnt. Enter öffnet die Bearbeitung.

**Markieren** oder Strg/Cmd + Klick wählt in dieser Bedienart ganze Blöcke aus; Umschalt + Klick einen Bereich. Kopieren/Einfügen erhält Dauer, Lücken und relative Abstände. Im Zeitraster wird die früheste Anfangszeit an der Zielminute ausgerichtet. In der tabellarischen Wochenübersicht bleiben die Uhrzeiten erhalten. Kollidiert die gesamte Blockauswahl, wird nichts teilweise eingefügt. **Auswahl löschen** entfernt nach der Rückfrage nur die ausgewählten ganzen Blöcke.

## Rechenregeln

Die bestätigte Vollzeitbasis beträgt **39 Wochenstunden**, davon **31 Stunden BZ und 8 Stunden VZ**.

| Beschäftigung | Gesamt-Soll | BZ-Soll | VZ-Soll |
|---|---|---|---|
| 100 % | 39:00 | 31:00 | 8:00 |
| 75 % | 29:15 | 23:15 | 6:00 |
| 50 % | 19:30 | 15:30 | 4:00 |
| 25 % | 9:45 | 7:45 | 2:00 |

Prozentwert oder Vertragszeit als Stunden:Minuten, z. B. **36:18**, eingeben. Die Vertragszeit wird als ganze Minutenzahl gespeichert, nicht aus einer gerundeten Prozentanzeige zurückgerechnet. Bei Prozenteingabe wird das Gesamt-Soll auf die nächste Minute gerundet. BZ-Soll wird auf die nächste Minute gerundet, VZ-Soll bekommt den Rest. Beide ergeben zusammen immer genau das Gesamt-Soll.

Ist gesamt = BZ + BZ/VZ + VZ. Pausen werden separat summiert. Differenz = Ist minus Soll. Die tatsächlichen BZ-/VZ-Anteile des ausgewählten Normal- oder Ferienplans werden nicht automatisch auf die Sollquote gezwungen.

Die Wochenbilanz zeigt Soll, Ist und Differenz für BZ, VZ und Gesamt. Die Tagesbilanz zeigt die Arbeits- und Pausenzeiten pro Tag. Die Anwesenheit dort ist die Summe der eingetragenen Zeiträume einschließlich Pausen; freie Lücken werden nicht hinzugerechnet. Ein tägliches Soll wird nicht erfunden, da die Excel-Vorlage Wochen-Sollwerte vorgibt.

Die Team-Besetzung zählt alle Personen. Bei minutengenauen Wechseln innerhalb einer Viertelstunde zeigt sie die kleinste bis größte gleichzeitige Besetzung, etwa **2–3**. Pausen zählen nicht dazu.

## Vergleich mit der Excel-Vorlage

Der Vorlagenvergleich steht im **Normalbetrieb** zur Verfügung; es gibt keinen ursprünglichen Ferienplan als Vergleich. **Zeiten mit der ursprünglichen Excel-Vorlage vergleichen** zeigt für gleichnamige Personen die abweichenden Tage, geänderten Minuten und Unterschiede bei den Vertragsstunden. Die Zuordnung erfolgt anhand des Namens. Wenn ein Name nicht zugeordnet werden kann, wird das ausdrücklich angezeigt.

In der Wochenübersicht werden zusätzliche oder fehlende Arbeitsminuten gegenüber der Vorlage direkt am jeweiligen Tag markiert. Bewusst geänderte Pläne dürfen natürlich von der Vorlage abweichen.

Der mitgelieferte ausgefüllte Dienstplan enthält **19 Personen und 331 Zeitblöcke**, davon 30 BZ/VZ-Blöcke. Der unbenannte Reserveplatz 20 wird nicht als beschäftigte Person gezählt. Der Originalplan liegt bereits vier Minuten unter dem Gesamt-Soll: Im Blatt „Arbeiter.“ stehen 26:02 Ist bei 26:06 Soll. Diese Abweichung wird nicht künstlich ausgeglichen.

## Excel-Export in die ursprüngliche Vorlage

**Excel exportieren** lädt eine neue XLSX-Datei für den ausgewählten Normal- oder Ferienplan herunter. Der Export verwendet die hochgeladene Datei **2027 Entwurf Dienstplan_GTS 20MA-15min.xlsx** als Vorlage und trägt die aktuellen Namen, Vertragsstunden und Zeiten in deren Tages- und Personenblätter ein. Die Quelldatei selbst wird nicht verändert.

Layout, Zellformatierungen, Druckausrichtung und verbundene Zellen der Originalblätter bleiben erhalten. Die Personentabs werden passend benannt. Ein unbesetzter Reserveplatz hat im Export null Vertragsstunden.

Wechsel innerhalb einer Viertelstunde lassen sich in einem einzigen Rasterfeld nicht vollständig berechnen. Deshalb enthält der Export zusätzlich:

- **Planzeiten:** Exakte Anfangs-/Endzeiten und ganze Minuten jedes Zeitraums; BZ/VZ steht rechnerisch als BZ und bleibt in der Bezeichnung erkennbar.
- **Auswertung:** Soll, Ist und Differenzen für BZ, VZ und Gesamt, einschließlich Teamsumme.
- **_Besetzung:** Ausgeblendetes Rechenblatt für minutengenaue Besetzung und die Min-/Max-Werte des ursprünglichen Tagesrasters.

Die Summen in den Originalblättern werden aus den exakten Planzeiten berechnet und sind bereits mit Ergebnissen vorbelegt. Excel berechnet sie beim Öffnen neu. Negative Differenzen werden lesbar als etwa **-0:04** dargestellt.

Das gedruckte Tagesraster ist die **Exportansicht**. Für Änderungen den HTML-Plan bearbeiten und neu exportieren. Alternativ lassen sich Beginn und Ende im Excel-Blatt **Planzeiten** ändern; dann rechnen Summen und Besetzung neu, während die Rasterbeschriftungen die ursprüngliche Exportansicht bleiben. Direkte Änderungen der Beschriftungen im Tagesraster verändern die maßgeblichen Detailzeiten nicht. Dieser Hinweis steht auch oben in den Tagesblättern.

**Mehr → Drucken** im HTML-Plan enthält die Bilanz und die Zeitpläne aller angelegten Personen. Im Druckdialog kann PDF ausgewählt werden. Die Anwendung ist eine wiederverwendbare Montag-bis-Freitag-Vorlage; unterschiedliche Kalenderwochen werden über eigene JSON-Sicherungen verwaltet.

## Durchgeführte Prüfungen

Viertelstunden-Bearbeitung und zwei Planarten:

- Einzelne Viertelstundenfelder innerhalb langer Blöcke sichtbar; rechteckige Auswahl über mehrere Personen und in der Personenwoche über mehrere Tage geprüft. Markieren verändert zunächst keine Zeiten.
- 80 zufällige Bereichsänderungen gegen eine unabhängige Minute-für-Minute-Berechnung verglichen, einschließlich krummer Anfangs-/Endminuten. Kein Verlust außerhalb der Auswahl.
- Das konkrete Pausenbeispiel 08:00–16:03 → BZ bis12:00, Pause12:00–12:30, BZ bis16:03 geprüft; letzte drei Minuten bleiben sichtbar und gerechnet.
- Füllen und Leeren als atomare Aktionen, vollständiges Rückgängig/Wiederholen, exakte Auswahl 08:31–09:03, Kopieren/Einfügen einschließlich Lücken/Bezeichnungen, Tastenkürzel und Abweisung unpassender Gesamtflächen geprüft.
- Ältere Ein-Plan-Daten als Normalplan übernommen; Ferien anfangs leer. Getrennte Zeiten/Besetzung und gemeinsame Namen/Vertragsstunden (z.B.30:03) nach wiederholtem Umschalten geprüft.
- Den anderen Plan für eine Person kopiert, unabhängige IDs und Rückgängig geprüft. JSON-Sicherung, Neuladen und Import erhalten beide Pläne vollständig.
- Excel für beide Planarten geöffnet und getrennte Arbeitsminuten, Planart-Hinweis und Dateinamen geprüft. Entfernen und Wiederherstellen einer Person erhält ihre beiden Pläne.
- Desktop (1600Pixel) und Handy (390Pixel), einschließlich Touch-Auswahl und Füllen zweier Viertelstunden, geprüft: Viertelstundenkästchen, Auswahl, Kategorienfarben, Minutenausnahmen und keine JavaScript-Fehler oder Seitenüberläufe.


Zusätzliche frühere Prüfungen der Oberfläche:

- Tagesplan als Startansicht, direkte Montag-bis-Freitag-Auswahl, alle 19 Personenspalten, drei sichtbare Besetzungsspalten und eingeklappte Nebenbereiche im Browser geprüft.
- Alle 56 Besetzungszeiträume eines Originaltages gegen unabhängig minutengenau gezählte BZ-/VZ-Werte geprüft, einschließlich aller Min-/Max-Bereiche.
- Neue Zeiträume nach unten und oben aufgezogen, Kollisionsfälle ohne Teiländerungen abgewiesen, 08:31–09:03 exakt als 32 Minuten gespeichert und Endzeit 16:03 sichtbar erhalten.
- Verschieben zwischen Personen, minutengenaue Tastaturbewegung, Verlängern um zehn Minuten, Palette ziehen, Kopieren/Einfügen und Rückgängig/Wiederholen nach der Vereinfachung erneut geprüft.
- Entfernen einer Person nach Bestätigung, Abbrechen ohne Änderungen, vollständiges Wiederherstellen mit Zeiten/Vertragsstunden und aktualisierte Team-Besetzung geprüft. Auch letzte Person entfernen, leeren Plan speichern/neu laden und neu anfangen geprüft.
- Excel nach Entfernen einer mittleren Person geöffnet: Reihenfolge/Namen, freie Reserveplätze, Vertragsminuten und Arbeitszeiten der verbleibenden Personen geprüft.
- Desktop (1600 Pixel) und Handy (390 Pixel) visuell geprüft, ohne Seitenüberlauf oder JavaScript-Fehler. Die Druckfunktion öffnet die Team-Bilanz vor dem Drucken und stellt deren vorherigen Zustand anschließend wieder her.

Vorherige vollständige Rechen- und Exportprüfung:

- 19 Verträge, 331 Zeitblöcke und die ursprünglichen BZ-/VZ-/Pausensummen wurden unabhängig mit den Excel-Eingaben und gespeicherten Ergebnissen verglichen.
- Alle 380 Tages-Gesamt-/BZ-/VZ-/Pausenwerte der belegten Personenspalten und 114 Vertrags-/Wochenwerte stimmen im Export mit der Vorlage überein.
- Alle ursprünglichen BZ/VZ-Rastereinträge bleiben im Excel-Export als solche erkennbar; die Kategorie zählt vollständig als BZ. Keine Aufteilungszeit erforderlich.
- Excel-Exporte wurden mit openpyxl gelesen, die XML-Struktur und die erhaltenen Zellstile, verbundenen Zellen sowie Druckausrichtungen geprüft. Anschließend wurden die Dateien mit LibreOffice tatsächlich neu berechnet: keine Formelfehler, unveränderte Tages-/Wochenwerte, Detailminuten, Differenzen und alle 280 Besetzungszeiträume.
- Alle 2.341 möglichen Vertragsminuten von 0:00 bis 39:00 wurden über Speicher-/Ladezyklen geprüft. BZ-Soll plus VZ-Soll bleibt exakt das Gesamt-Soll.
- 08:31–09:03 ergibt exakt 32 Minuten. Ein Ende 16:03 wird eingegeben, angezeigt und exportiert, ohne es auf das Raster zu runden.
- Ein absichtlich um 28 Minuten verlängerter Montag wurde im Vorlagenvergleich exakt als Änderung 17:00–17:28 erkannt.
- Wochenübersicht mit 19 Personen und 95 Tagesfeldern, Bearbeitung pro Tag, Wechsel zwischen Ansichten, Bausteine aus der Palette, Verschieben zwischen Personen/Tagen, minutengenaues Verlängern/Kürzen und Abfangen von Überschneidungen im Browser geprüft.
- Mehrfach- und Bereichsauswahl, Kopieren/Einfügen, Tastenkürzel, ausgewähltes Löschen sowie Rückgängig/Wiederholen geprüft. 32 + 35 Minuten mit 7 Minuten Lücke bleiben auch beim Einfügen ab 16:03 exakt erhalten. Kollisionsfälle verändern den Plan nicht teilweise.
- Desktop und Mobilansicht geprüft: kein Seitenüberlauf, normale Texteingaben bleiben bedienbar, keine JavaScript-Fehler.

Die Browserprüfung erfolgte mit Playwright/Chromium, weil kein Browser-Plugin verfügbar war. Aktuelle Bildschirmaufnahmen der Wochen- und Tagesansichten wurden visuell angesehen. Geprüft wurden Tabellenaufbau, Beschriftung, Lesbarkeit der Uhrzeiten, unterschiedliche Kategorienfarben, Abstände, Scrollverhalten und die Darstellung genauer Endzeiten. Temporäre Prüfdateien werden nicht mitgeliefert.

Das direkte Öffnen über file:// war in der Testumgebung durch die Browserrichtlinie gesperrt; die Funktion wurde über einen lokalen HTTP-Server getestet. Die ausgelieferte Datei enthält alle benötigten Ressourcen. Bei gesperrter Browser-Speicherung gibt die Anwendung einen Hinweis; JSON-Sicherungen bleiben verfügbar.

Die eingebettete ZIP-Bibliothek ist fflate 0.8.2. Ihr npm-Paket wurde beim Einrichten per SHA-512-Integrität geprüft. Die Lizenz liegt als **fflate-LICENSE.txt** bei. Im Betrieb werden keine externen Bibliotheken nachgeladen.
