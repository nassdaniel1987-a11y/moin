# Dienstplan – vollständige Übergabe an einen lokalen Chat

Stand: **16. Oktober 2026**, Zeitzone des Nutzers **Europe/Berlin**.

Diese Datei fasst die bisherige Zusammenarbeit zusammen. Sie ist kein wörtliches Chatprotokoll. Zusammen mit `Hinweise.md`, dem vollständigen Code in `Wochenplan.html` und beiden Original-Excel-Dateien ermöglicht sie die lokale Weiterarbeit.

## 1. Ziel und aktueller Auftrag

Aus vorhandenen Excel-Dienstplänen sollte eine einfach nutzbare HTML-Anwendung entstehen. Der Nutzer möchte Dienstzeiten übersichtlich abstimmen, direkt wie in Excel bearbeiten und wieder in die ursprüngliche Excel-Vorlage exportieren können.

Der zuletzt beauftragte Schritt ist die Zusammenstellung dieses vollständigen lokalen Ordners und einer Markdown-Übergabe. Dafür wurde die Anwendung nicht erneut umgebaut. Der zuletzt entwickelte Funktionsstand ist enthalten.

Der Nutzer hat die reine Reduzierung oder das Verstecken von Bedienelementen ausdrücklich als unzureichend kritisiert. Maßgeblich ist **einfacheres Eintragen und Ändern der Zeiten**. Die zuletzt ausdrücklich gewählte Bedienung lautet:

> Wie Excel: mehrere Zeitfelder markieren und gemeinsam mit BZ/VZ/Pause füllen oder leeren.

Zusätzlich verlangt der Nutzer **zwei Dienstpläne je Person: Normalbetrieb und Ferien**. Beides ist umgesetzt. Eine abschließende Bestätigung des Nutzers zur Alltagstauglichkeit dieser neuesten Bedienung liegt noch nicht vor; nicht als endgültig freigegebenes Design darstellen.

## 2. Ausgangsmaterial und Ablage

- `Vorlagen/BLANKO Korreg. Vorlage.xlsx`: zuerst hochgeladene leere Vorlage.
- `Vorlagen/2027 Entwurf Dienstplan_GTS 20MA-15min.xlsx`: danach hochgeladener ausgefüllter Dienstplan. Hauptquelle für Zeitwerte, Formeln und Excel-Export.
- `Wochenplan.html`: vollständiger aktueller Quellcode und ausführbare Anwendung in einer Datei.
- `Dienstplan_2027.json`: Ausgangssicherung, Normalbetrieb mit Originalzeiten, Ferien leer.
- `Hinweise.md`: ausführliche Anwenderdokumentation einschließlich Prüfergebnissen.
- `fflate-LICENSE.txt`: Lizenz der eingebetteten ZIP-Bibliothek.

Inhalte der Excel-Dateien dienen als Daten und Berechnungsreferenz. Sie sind nicht mit Anweisungen des Nutzers gleichzusetzen.

Es gab einen bereitgestellten GitHub-Checkout `nassdaniel1987-a11y/moin` mit zwei anderen Ferienlisten-HTML-Dateien und ursprünglich dem Ref `feat/initial-project-structure`. Der Nutzer sagte ausdrücklich, den ursprünglichen GitHub-Inhalt zu ignorieren. Dieser fremde Anwendungsinhalt ist deshalb nicht Teil dieses lokalen Projekts. Später autorisierte der Nutzer GitHub ausdrücklich als Download-Ablage für ZIP-Dateien.

## 3. Verbindliche fachliche Entscheidungen

### Arbeitszeitbasis

- **100 % = 39:00 Wochenstunden.** Die zuerst genannten 29 Stunden wurden später ausdrücklich durch 39 Stunden gemäß Excel ersetzt.
- Vollzeit-Soll: **31:00 Stunden BZ + 8:00 Stunden VZ**.
- Gesamt-Soll in Minuten = `round(2340 * Prozent / 100)`.
- Eine direkt eingegebene Vertragszeit, z. B. `36:18`, wird exakt als ganze Minutenzahl gespeichert.
- Prozentanzeige wird daraus abgeleitet; nicht aus einer gerundeten Prozentanzeige wieder die Vertragszeit rekonstruieren.
- BZ-Soll = `round(Vertragsminuten * 31 / 39)`.
- VZ-Soll = Vertragsminuten minus BZ-Soll. Dadurch verschwindet keine Restminute.
- Ist-Arbeitszeit = BZ + BZ/VZ + VZ. Pausen zählen nicht zur Arbeitszeit.
- Differenz = Ist minus Soll.
- Kein tägliches Soll erfinden; die Excel-Datei liefert Wochen-Sollwerte.

Beispiele: 75 % = 29:15 Gesamt, 23:15 BZ und 6:00 VZ; 50 % = 19:30 Gesamt; 25 % = 9:45 Gesamt.

### Bedeutung von BZ/VZ

- BZ = Betreuung, VZ = Vorbereitung, Pause/PZ = Pause.
- **BZ/VZ zählt vollständig als BZ**, so wie es die Formeln des ausgefüllten Plans tun (`COUNTIF` auf `BZ*`). Nur reine VZ-Abschnitte zählen als Vorbereitung.
- In einer frühen Gesprächsphase war eine verschiebbare innere Trennlinie gewünscht. Das wurde nach Prüfung des ausgefüllten Plans und weiterer Nutzerkorrektur durch die jetzige Regel ersetzt. **Keine zusätzliche Aufteilungszeit oder BZ/VZ-Trennlinie wieder einführen.**
- BZ/VZ muss optisch von BZ zu unterscheiden sein. Aktuell: BZ türkis, VZ violett, BZ/VZ orange, Pause grau; Viertelstundenansicht mit hellen Zellfarben.

### Minuten und Viertelstunden

- Anzeige und normale Feldauswahl in **15-Minuten-Kästchen**.
- Fachliche Daten und Rechenoperationen bleiben **minutengenau**, etwa Arbeitsende `16:03`.
- Keine stillen Rundungen, Restminutenverluste oder Abzüge wegen des Anzeigerasters.
- Eine Pause innerhalb von BZ muss den Zeitraum automatisch aufteilen. Beispiel: BZ `08:00–16:00`, Pause `12:00–12:30` ergibt BZ `08:00–12:00`, Pause `12:00–12:30`, BZ `12:30–16:00`.
- Dasselbe gilt bei einem ursprünglichen Ende `16:03`; die letzten drei Minuten müssen erhalten bleiben.
- Der Nutzer berichtete einmal +28 Minuten und meldete anschließend selbst „fehler gefunden“. Das ist kein bestätigter offener Rechenfehler. Der Vorlagenvergleich kann solche Änderungen minutengenau anzeigen.

### Normalbetrieb und Ferien

- Je Person zwei getrennte Montag-bis-Freitag-Zeitpläne.
- Namen und Vertragsstunden gelten gemeinsam für beide Planarten.
- Eingetragene Zeiten, Pausen, Ist-Stunden, Differenzen und Besetzung werden je Plan getrennt betrachtet; nicht addieren.
- Normalbetrieb enthält anfangs den Originalplan, Ferien ist zunächst leer.
- Umschalten gilt für die gesamte Teamansicht und alle Ansichten.
- Der andere Plan kann nach Bestätigung für die ausgewählte Person übernommen werden. Danach bleiben beide unabhängig bearbeitbar.
- JSON-Sicherung enthält beide Pläne. Excel-Export enthält den gerade ausgewählten Plan.

## 4. Umgesetzte Bedienung

### Zeitfelder ausfüllen – Standard

- Tagesplan als Startansicht, Montag bis Freitag per Schaltflächen.
- Alle Mitarbeitenden nebeneinander, links die Zeitachse, rechts BZ+VZ/BZ/VZ-Besetzung.
- Pro Person und Tag 56 sichtbare Viertelstundenfelder von 06:00 bis 20:00, auch innerhalb langer Zeiträume.
- Rechteckige Auswahl durch Ziehen, auch über mehrere Personen. Das Markieren verändert zunächst nichts.
- Danach BZ, VZ, BZ/VZ oder Pause wählen; Leeren entfernt nur den Bereich.
- Bestehende Intervalle werden an den Auswahlgrenzen geschnitten. Außerhalb der Auswahl bleiben Minuten, Kategorien und Bezeichnungen erhalten.
- Auswahlzeiten Von/Bis können direkt in `HH:MM` eingegeben werden, auch außerhalb des Viertelstundenrasters.
- Doppelklick auf belegte Kästchen öffnet zusätzlich die genaue Einzelbearbeitung des zugrunde liegenden Intervalls.
- Kopieren/Einfügen umfasst die gesamte Fläche, einschließlich freier Lücken und genauer Minuten. Vorhandene Zielzeiten innerhalb der Fläche werden ersetzt.
- Passt die ganze Kopie nicht an das Ziel, wird nichts teilweise eingefügt.
- Tastatur: B/V/M/P füllen, Entf/Rücktaste leert, Strg/Cmd+C/V kopiert/fügt ein, Pfeiltasten verschieben die Auswahl, Escape hebt sie auf.
- Normale Text-Tastenkürzel in Eingabefeldern bleiben erhalten.
- Touch-Auswahl und Füllen zweier Viertelstunden wurden ebenfalls geprüft.

### Weitere Ansichten und Werkzeuge

- Wochenübersicht: Personen als Zeilen, Montag bis Freitag als Spalten. Exakte Zeiten je Tagesfeld, direkte Bearbeitung und Hinzufügen. Verschieben in ein anderes Tagesfeld erhält die Uhrzeiten.
- Personenwoche: eine Person, fünf Tage nebeneinander. Bereichsauswahl kann mehrere Tage umfassen.
- Bedienart „Blöcke verschieben“ erhält Kalendergesten: neue Zeiträume aufziehen, Bausteine aus der Palette ziehen, Blöcke verschieben, Kanten verlängern/kürzen, genaue Eingabe per Klick.
- Bestehende Blockbewegungen arbeiten minutengenau, Umschalt+Pfeil auf/ab in 15-Minuten-Schritten.
- Mehrere ganze Blöcke markieren, kopieren, einfügen und löschen bleibt in dieser Bedienart verfügbar.
- Mitarbeitende hinzufügen, umbenennen, Vertragszeit ändern und entfernen. Entfernen betrifft beide Pläne und ist rückgängig möglich. Auch die letzte Person kann entfernt werden.
- Bis zu 30 Rückgängig-/Wiederholen-Schritte im laufenden Fenster, einschließlich gemeinsamer Bereichsänderungen und Entfernen einer Person. Historie wird nicht dauerhaft gespeichert.
- Team- und Personenbilanz, Tagesbilanz, Druck und Normalplan-Vorlagenvergleich.
- Automatische Browser-Speicherung, JSON-Sicherung und Wiederherstellung.

## 5. Feststellungen zur Original-Excel-Datei

- Originalbestand: **19 benannte Personen, 331 Zeitblöcke, davon 30 BZ/VZ-Blöcke**.
- Platz 20 ist unbenannte Reserve und wird nicht als Person mitgerechnet.
- In der Vorlage besteht bereits ein echter Fehlbetrag von vier Minuten: Blatt „Arbeiter.“ mit 26:02 Ist bei 26:06 Soll. Teamsumme: 581:41 Ist bei 581:45 Soll. Diese Abweichung nicht künstlich ausgleichen.
- Es wurden 13 nicht am Viertelstundenraster liegende Zeitgrenzen übernommen.
- Die ursprüngliche BZ-Besetzungsformel berücksichtigt teilweise nur die Spalten C:O und damit nicht alle Personen. Die HTML-Anwendung und ihr Export berücksichtigen alle aktuell angelegten Personen.
- Bei Wechseln innerhalb einer Viertelstunde zeigt die Besetzung Minimum bis Maximum, z. B. `2–3`, statt eine gleichbleibende Besetzung vorzutäuschen.

Relevante Excel-Struktur:

- Tagesblätter Montag bis Freitag, danach 20 Personen-/Reserveblätter.
- Tagesraster Zeilen 5 bis 60 = 06:00 bis 20:00; Namen in Zeile 3, Personenspalten C:V.
- Tageswerte Zeile 72 Arbeitszeit, 73 BZ, 74 VZ, 75 Pause.
- Personenblatt F2 Vertragszeit; H60 Gesamt-Soll, H61 BZ-Soll, H62 VZ-Soll; H65 Ist, H66 BZ, H67 VZ, H68 Pause.

## 6. Excel-Export und seine Grenze

- Die ausgefüllte Original-XLSX ist als Base64-Konstante `EXCEL_TEMPLATE` in der HTML-Datei eingebettet.
- Der Export trägt aktuelle Namen, Verträge, Tageszeiten und Werte in deren Originalblätter ein. Layout, Stile, Druckausrichtung und verbundene Zellen bleiben erhalten.
- Freie Plätze werden mit null Vertragszeit geführt. Veraltete Personennamen aus dem ursprünglichen Shared-Strings-Pool werden nicht einfach mitgeführt.
- Zusätzliche Blätter: `Planzeiten` für exakte Intervalle und ganze Minuten; `Auswertung` für Soll/Ist/Differenzen; `_Besetzung` als ausgeblendete minutengenaue Rechengrundlage.
- Tages- und Wochenformeln beziehen sich auf diese exakten Zeiten. Gespeicherte Werte sind vorbelegt; Excel kann beim Öffnen neu rechnen.
- Negative Differenzen werden lesbar als Text, z. B. `-0:04`, dargestellt.
- Dateiname und Hinweis in den Tagesblättern unterscheiden Normalbetrieb und Ferien.

**Wichtige Grenze:** Das gedruckte Viertelstundenraster im Export ist eine Momentaufnahme. Für Änderungen den HTML-Plan bearbeiten und erneut exportieren. Änderungen an Beginn/Ende im Blatt `Planzeiten` rechnen Summen und Besetzung neu, aktualisieren aber nicht die Rasterbeschriftungen. Direkte Beschriftungsänderungen im Tagesraster ändern nicht die maßgeblichen Detailzeiten. Das ist auch im Export vermerkt.

Ein allgemeiner Excel-Import beliebiger bearbeiteter Arbeitsmappen oder eine vollständige bidirektionale Synchronisierung ist nicht implementiert. `Mehr → Datei öffnen` lädt JSON-Sicherungen, keine XLSX-Dateien.

## 7. Technischer Aufbau

### Laufzeit

- Eigenständige HTML-Datei mit eingebettetem CSS und JavaScript, ohne React, Vite, npm-Projekt oder Server-Backend.
- Eingebettete Bibliothek **fflate 0.8.2** für ZIP/XLSX, Lizenz separat beigelegt. Das npm-Paket wurde in der ursprünglichen Umgebung gegen seine SHA-512-Integrität geprüft.
- Keine extern nachgeladenen Bibliotheken; kein API-Schlüssel erforderlich.
- Zeitwerte sind ganze Minuten seit Mitternacht. Grenzen `MIN=360`, `MAX=1200`; Vollzeit `FULL=2340` Minuten.
- Darstellung `SCALE=54/60` Pixel pro Minute, also 13,5 Pixel pro Viertelstunde und 756 Pixel für 14 Stunden.
- Farben und Zellflächen sind Darstellung; fachliche Daten bleiben zusammenhängende, bei Änderungen teilbare Intervalle.

### Gespeichertes Datenmodell

```json
{
  "version": 2,
  "planKind": "normal",
  "people": [
    {
      "name": "Beispiel",
      "fte": 100,
      "targetMinutes": 2340,
      "blocks": [
        { "id": "eindeutig-1", "day": 0, "type": "care", "start": 480, "end": 960 }
      ],
      "alternateBlocks": []
    }
  ]
}
```

- `planKind`: `normal` oder `holiday`.
- **`blocks` enthält immer den gerade aktiven Plan, `alternateBlocks` den anderen.** Bei `holiday` enthält `blocks` die Ferienzeiten, bei `normal` die Normalzeiten. Nicht fälschlich annehmen, dass `blocks` immer Normalzeiten bedeutet.
- Umschalten tauscht für alle Personen beide Arrays und ändert `planKind`.
- `day`: 0 Montag bis 4 Freitag. `type`: `care`, `prep`, `mixed`, `pause`.
- `start`/`end`: ganze Minuten zwischen 360 und 1200, Ende exklusiv. Optional `label` für eine Bezeichnung.
- IDs müssen über beide Planarten und alle Personen eindeutig sein. Kopien bekommen neue IDs.
- `validate` prüft unter anderem Zeiten, Überschneidungen innerhalb einer Person/Planart, IDs, maximal 20 Personen und maximal 300 Intervalle je Person und Planart.
- Ältere Version-2-Daten ohne `planKind`/`alternateBlocks` werden als Normalplan mit leerem Ferienplan übernommen.
- Optional bleibt ein Textfeld `notice` aus früheren Ausgangsdaten erhalten.
- Browser-Speicherschlüssel: **`wochenplan-bloecke-v2`**. Bitte bei weiteren Änderungen keine Nutzerdaten stillschweigend verwerfen.
- Die JSON-Datei im Paket ist der ursprüngliche Ausgangsplan, nicht der aktuelle Browser-Speicher des Nutzers.

### Einstiegspunkte im Code

| Funktion/Bereich | Aufgabe |
|---|---|
| `INITIAL_PLAN`, `EXCEL_TEMPLATE` | Eingebettete Ausgangsdaten und Original-XLSX |
| `validate`, `blockError` | Datenvalidierung und Kollisionsprüfung |
| `totals` | Minutenbasierte Soll-/Ist-Berechnung |
| `render`, `renderCalendar`, `renderWeekTeam`, `renderQuarterCells` | Oberfläche, Ansichten und Viertelstundenkästchen |
| `coverageForDay` | Min-/Max-Besetzung über alle Personen |
| `selectedRange`, `rangePoint`, `rangeSelection` | Aktuelle Bereichsauswahl und exakte Grenzen |
| `outsideRange`, `compactBlocks`, `applyRange` | Intervalle schneiden, Bereich ersetzen/leeren und ggf. zusammenfassen |
| `copyRange`, `pasteRange` | Flächen kopieren/einfügen einschließlich Lücken |
| `setRangeMode`, `setupRangeEditing` | Umschalten zwischen Feldern und Blöcken |
| `switchPlanKind`, `setupSeasons`, `syncSeasonUI` | Normalbetrieb/Ferien und gemeinsame Stammdaten |
| `restoreHistory`, `save` | Rückgängig/Wiederholen und Speicherung |
| `compareTimes`, `renderComparison`, `referenceFor` | Normalplan-Vorlagenvergleich |
| `exportWorkbook` | Original-XLSX lesen, XML anpassen, exakte Rechenblätter ergänzen und ZIP schreiben |

Die Datei ist schrittweise gewachsen. `render`, `renderCalendar`, `renderSummary` und `save` werden teilweise durch spätere Wrapper ergänzt. Bei Änderungen die endgültige Aufrufkette beachten; nicht nur die erste Funktionsdeklaration lesen.

Bereichsauswahl verwendet Ereignisbehandlung in der Capture-Phase vor der älteren Blockbedienung. Deshalb neue Pointer-/Tastaturhandler mit beiden Bedienarten prüfen. Texteingaben und Dialoge dürfen nicht von globalen Tastenkürzeln überschrieben werden.

Rückmeldungen (`#message`) liegen inzwischen fest über der Seite. Sie dürfen das Zeitraster während eines Ziehvorgangs nicht verschieben; ein entsprechender Fehler wurde während der Entwicklung vor Auslieferung behoben.

## 8. Bisherige Prüfungen und deren Aussage

Die unten genannten Prüfungen wurden im vorherigen Cloud-Arbeitsbereich tatsächlich ausgeführt. Die ausführliche Liste steht auch in `Hinweise.md`. Die meisten waren temporäre Python-/Playwright-Skripte und sind **keine mitgelieferte dauerhafte Testsuite**. Temporäre Screenshots und Prüfdateien wurden entfernt; Quellcode, Ausgangsdaten und Originalvorlagen sind vollständig enthalten.

### Excel und Berechnung

- Ursprüngliche 19 Verträge, 331 Intervalle und BZ/VZ/Pausenwerte mit Excel verglichen.
- Ursprüngliche Tages-Kategoriewerte unabhängig reproduziert; anschließend 380 exportierte Tageswerte und 114 Vertrags-/Wochenwerte geprüft.
- Alle 2.341 möglichen Vertragsminuten von 0 bis 2.340 durch Speicher-/Ladezyklen geprüft; BZ-Soll plus VZ-Soll blieb immer Gesamt-Soll.
- 08:31–09:03 = exakt 32 Minuten; 16:03 bleibt erhalten; absichtliche +28 Minuten im Vorlagenvergleich erkannt.
- Exportdateien mit openpyxl gelesen, XML, Stile, verbundene Zellen und Druckausrichtung geprüft.
- Frühere vollständige Exporte zusätzlich tatsächlich mit LibreOffice neu berechnet: keine Formelfehler, unveränderte Detail-/Tages-/Wochenwerte und alle 280 Besetzungszeiträume geprüft.
- Nach den neuesten Änderungen Normal- und Ferienexport getrennt geöffnet und ihre exakten Arbeitsminuten, Planart-Hinweise und Dateinamen geprüft. Die komplette LibreOffice-Prüfung wurde nicht nach jeder reinen Bedienänderung erneut ausgeführt.

### Neue Bereichsbedienung

- 80 zufällige Bereichsänderungen mit einer unabhängigen Minute-für-Minute-Berechnung verglichen, auch bei Grenzen außerhalb des Viertelstundenrasters.
- Rechteck über mehrere Personen und über mehrere Tage einer Personenwoche geprüft.
- Füllen/Leeren, automatische Aufteilung, Grenzen 16:03 und exakte 32-Minuten-Auswahl geprüft.
- Kopieren/Einfügen einschließlich Lücken, Bezeichnungen und krummer Minuten; unpassende Kopie und ungültige Zeiten ohne Teiländerung abgewiesen.
- Rückgängig/Wiederholen, Tastenkürzel, Auswahlbewegung, Doppelklick und Wechsel zur älteren Blockbedienung geprüft.
- Alle 56 Besetzungszeiträume eines Originaltages unabhängig minutengenau gegengezählt.

### Zwei Pläne und Oberfläche

- Alte Datenmigration, leerer Ferienplan, wiederholtes Umschalten ohne Datenverlust.
- Gemeinsamer Name und Vertragszeit 30:03, getrennte Zeiten und Besetzung.
- Anderen Plan für eine Person kopiert, neue IDs und Rückgängig geprüft.
- JSON-Sicherung, Neuladen und Import mit beiden Plänen geprüft.
- Entfernen einer Person samt beider Pläne und vollständiges Wiederherstellen geprüft; leeren Gesamtplan und erneutes Hinzufügen ebenfalls geprüft.
- Desktop 1600 Pixel und Mobilansicht 390 Pixel mit Chromium/Playwright geprüft; neueste Auswahl zusätzlich per emulierten Touch-Ereignissen getestet.
- Keine JavaScript-Fehler oder Seitenüberläufe in den getesteten Abläufen.

Browser-Plugin war in der vorherigen Umgebung nicht verfügbar; deshalb Playwright mit Chromium. Direktes Öffnen per `file://` war dort durch die Browserrichtlinie gesperrt. HTTP-Lokalbetrieb wurde geprüft. Das ist keine Prüfung sämtlicher Browser, Betriebssysteme oder echter Mobilgeräte.

## 9. Lokal starten und weiterentwickeln

Einfacher Einstieg: `Wochenplan.html` öffnen. Falls Browserrichtlinien oder Speicherung das verhindern, im Projektordner einen lokalen Server starten:

```sh
python -m http.server 8001 --bind 127.0.0.1
```

Alternativ `python3` beziehungsweise unter Windows `py`. Im eigenen Browser `http://127.0.0.1:8001/Wochenplan.html` öffnen. Es sind keine Python-Pakete für den Betrieb erforderlich.

Entwicklungsprüfungen können optional Python mit Playwright/Chromium und openpyxl verwenden. LibreOffice eignet sich für echte XLSX-Neuberechnung. Diese Werkzeuge sind nicht Teil der Anwendung und nicht als installiert auf dem neuen lokalen Rechner vorauszusetzen. Es gibt keine `package.json`, keinen npm-Build und derzeit keine committed Testkonfiguration.

Vor Änderungen eine eigene JSON-Sicherung und eine Kopie der HTML-Datei anlegen. Eingebettete Originaldaten und XLSX nicht versehentlich überschreiben. Eine lokale Source-Aufteilung wäre eine spätere technische Entscheidung; die offline nutzbare Einzeldatei sollte dabei als einfach verwendbares Ergebnis erhalten bleiben.

## 10. Grenzen und offene Rückmeldungen

- Bis 20 Personen, Montag bis Freitag, 06:00 bis 20:00. Keine Wochenenden, Nachtschichten oder kalenderdatumsbasierte Jahresverwaltung.
- Unterschiedliche Kalenderwochen werden über eigene JSON-Sicherungen verwaltet.
- Kein Backend, keine Mehrbenutzer-Synchronisierung, keine Benutzerkonten.
- Browser-Speicher ist lokal an Browser/Adresse gebunden. Für einen Umzug sind die eigenen JSON-Sicherungen maßgeblich.
- Zwischenablage und Rückgängig-Historie gelten nur im laufenden Fenster.
- Die interne Zwischenablage ist kein allgemeiner Excel-/System-Zwischenablageimport.
- Zwei Planarten teilen sich Namen und Vertragsstunden; getrennte Ferien-Verträge oder besondere Ferien-Sollformeln wurden nicht angefordert oder implementiert.
- Excel-Raster ist Exportansicht, kein vollständig bidirektional gekoppelter Editor.
- Vorlagenvergleich ordnet über Namen zu und ist nur im Normalbetrieb verfügbar. Umbenannte Personen können ihre Zuordnung verlieren; das wird angezeigt.
- Die jüngste Bedienung ist technisch geprüft. Ob der Nutzer sie im Alltag nun wirklich einfacher findet, muss im weiteren Gespräch überprüft werden.
- Es liegt keine offene bestätigte +28-Minuten-Rechenstörung vor.

Bitte nicht ohne konkreten Anlass neue Funktionen, Frameworks oder Pflichtinstallationen einführen. Der Nutzer möchte geringe Einstiegshürden, direktes Arbeiten und möglichst wenige unnötige Rückfragen.

## 11. Versions- und Ablagehistorie

Repository als Download-Ablage: `https://github.com/nassdaniel1987-a11y/moin`, Branch `codex/dienstplan-download`.

Wichtige bisherige Commits:

- `abb392d7917b4a34830a2615f5aad88a5716bd14`: Wochenübersicht, Block-Zwischenablage und exakter Export in die Originalvorlage.
- `53fe36c8f7de8bb307fb03821ab774f55c6fb450`: vereinfachter Tagesplan und Entfernen von Mitarbeitenden.
- **`e1492a636ec97e407d2037b2c50549aadb35c364`**: aktueller Programmstand mit Viertelstunden-Bereichsbearbeitung und zwei Planarten.

Der bisherige Download `downloads/Dienstplan-Paket.zip` enthält diesen aktuellen Programmstand. Sein SHA-256-Wert ist `8df6315ee0b36190f8dbcde685e54c89230cbbdfb2b929742b564e2a6ce56b6f`.

Der neue komplette Umzugsordner wird zusätzlich als **`downloads/Dienstplan-Lokal-Komplett.zip`** abgelegt. Er enthält denselben unveränderten Programmcode, zusätzlich beide Originalvorlagen und diese Übergabe. Sein Verpackungscommit folgt auf den oben genannten Programmstand. Die Prüfsummen der enthaltenen Dateien stehen in `SHA256SUMS.txt`.

Im bisherigen Cloud-Checkout wurden nur ZIP-Downloads versioniert; die HTML-Quelldatei lag außerhalb des Checkouts. **Hier im lokalen Ordner ist `Wochenplan.html` die maßgebliche direkt bearbeitbare Quelle.** Keine alte ZIP-Version oder die unbeteiligten Ferienlisten-Dateien als Ausgangspunkt verwenden.

## 12. Starttext für den neuen lokalen Chat

Den folgenden Text kann der Nutzer zusammen mit diesem Ordner an den lokalen Chat geben:

> Wir führen meine Dienstplan-Anwendung lokal weiter. Lies zuerst `UEBERGABE.md` und `Hinweise.md` und prüfe den aktuellen Code in `Wochenplan.html`. Die beiden Original-Excel-Dateien liegen in `Vorlagen/`. Behalte die bestätigten Regeln bei: 100 % sind 39 Wochenstunden, BZ/VZ zählt vollständig als BZ, alle Rechnungen bleiben minutengenau. Die Standardbedienung ist wie Excel: Viertelstundenfelder über eine oder mehrere Personen markieren und gemeinsam füllen oder leeren; eine eingefügte Pause teilt bestehende BZ-Zeiten automatisch. Pro Person gibt es getrennte Normal- und Ferienzeiten bei gemeinsamen Namen und Vertragsstunden. Das Programm soll einfach lokal und möglichst ohne Installation nutzbar bleiben. Meine eigene aktuelle JSON-Sicherung, falls ich sie beigefügt habe, hat Vorrang vor dem mitgelieferten Ausgangsplan. Starte beziehungsweise prüfe den aktuellen Stand und hilf mir bei den Änderungen, die ich als Nächstes nenne. Verändere dabei nicht ungefragt die Berechnungsregeln oder ersetze den bestehenden Stand durch einen Neubau.
