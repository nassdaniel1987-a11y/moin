# Wochenplan: Bedienung und Berechnung

`Wochenplan.html` herunterladen und im Browser öffnen. Zum Übernehmen des ausgefüllten Dienstplans auch `Dienstplan_2027.json` herunterladen und in der HTML-Version über **Datei öffnen** auswählen. Die Original-Excel-Dateien wurden nicht verändert.

Die HTML-Datei enthält alle benötigten Ressourcen. Sie benötigt keinen Account und lädt keine externen Bibliotheken. Browserdaten bleiben lokal; für eine eigene Kopie **Sicherung speichern** verwenden. JSON-Sicherungen werden unterstützt, direkter Excel-Import ist nicht eingebaut.

## Bearbeiten

Person links auswählen, Namen und Beschäftigungsumfang einstellen. Alternativ die Vertragsstunden als Stunden:Minuten eingeben, etwa `36:18`. Prozent und Stunden werden gegenseitig berechnet. Die Vertragszeit wird als ganze Minutenzahl gespeichert und beim Laden nicht aus einer gerundeten Prozentanzeige zurückgerechnet. Bis zu 20 Personen sind möglich.

Über **+ BZ**, **+ VZ**, **+ BZ/VZ** oder **+ Pause** einen Zeitraum anlegen. Auch eine freie Kalenderstelle lässt sich anklicken. Bezeichnungen wie Hort, Team, Büro oder KIFAZ sind optional.

- Ganzen Block ziehen: Uhrzeit und Wochentag ändern, Dauern bleiben erhalten.
- Ober-/Unterkante ziehen: Beginn bzw. Ende ändern.
- Innere BZ/VZ-Trennlinie ziehen: BZ oben, VZ unten. Jede Minute wird genau einer Kategorie zugeordnet.
- Block anklicken: minutengenaue Zeiten eingeben, Art ändern oder Block löschen.
- Ziehen, die innere Trennlinie und die Pfeiltasten ändern in 1-Minuten-Schritten. Umschalt + Pfeil auf/ab ändert um 15 Minuten. Die Viertelstundenlinien sind nur eine optische Orientierung. Die genaue Eingabe unterstützt beliebige Minuten. Überschneidungen werden abgefangen.
- Tab erreicht Blöcke und Griffe. Pfeile verschieben Blöcke; Pfeil auf/ab verändert den fokussierten Griff. Enter öffnet die Eingabe.

Am Handy ist der Kalender seitlich scrollbar. **Drucken** enthält die Übersicht und die Pläne aller angelegten Personen; im Browser-Druckdialog kann auch PDF gewählt werden.

Es ist eine wiederverwendbare Montag-bis-Freitag-Vorlage von 06:00 bis 20:00. Unterschiedliche Kalenderwochen werden als separate Sicherungen gespeichert.

## Rechenregeln

Die Vollzeitbasis wurde nach Rückfrage vom Nutzer bestätigt: **39 Wochenstunden**, davon **31 BZ und 8 VZ**. Die frühere Angabe 29 Stunden ist ersetzt.

| Umfang | Gesamt-Soll | BZ-Soll | VZ-Soll |
|---|---|---|---|
| 100 % | 39:00 | 31:00 | 8:00 |
| 75 % | 29:15 | 23:15 | 6:00 |
| 50 % | 19:30 | 15:30 | 4:00 |
| 25 % | 9:45 | 7:45 | 2:00 |

Gesamt-Soll bei Prozenteingabe = 39 Stunden × Beschäftigungsumfang, auf die nächste volle Minute gerundet. Bei direkter Eingabe der Vertragsstunden werden deren Minuten unverändert verwendet. BZ-Soll = Gesamt-Soll × 31/39, auf Minuten gerundet. VZ-Soll = Gesamt-Soll minus BZ-Soll. Dadurch ergeben beide Teile zusammen stets das Gesamt-Soll, ohne Rundungsreste.

Die Istwerte entstehen aus den tatsächlichen Zeitblöcken. BZ/VZ-Blöcke zählen vor ihrer Trennlinie als BZ, danach als VZ. Ist gesamt = BZ-Ist + VZ-Ist. Pausen werden separat summiert und nicht als Arbeitszeit gezählt. Differenz = Ist minus Soll. Die Ist-Aufteilung wird nicht automatisch auf die Sollquote gezwungen.

**Wochenbilanz** zeigt Soll, Ist und Differenz für BZ, VZ und Gesamt. **Tagesbilanz** zeigt BZ, VZ, Arbeitszeit und Pause je Wochentag. Anwesenheit ist hier die Summe der eingetragenen Blöcke einschließlich Pausen; freie Lücken werden nicht hinzugerechnet. Ein tägliches Soll wird nicht erfunden, da Excel nur Wochen-Sollwerte vorgibt.

**Besetzung im Team** berücksichtigt alle Personen je Viertelstunde. Bei minutengenauen Wechseln erscheint der kleinste bis größte gleichzeitig vorhandene Wert, etwa `2–3`. Die interne BZ/VZ-Trennlinie wird berücksichtigt. Pausen zählen nicht zur Besetzung. Gleichzeitige BZ und VZ derselben Person sind ausgeschlossen.

## Erkenntnisse aus dem ausgefüllten Excel-Plan

- 19 benannte Personen, ein leerer Reserveplatz 20. Dieser Reserveplatz wird beim Übernehmen nicht als beschäftigte Person gezählt und erhöht deshalb nicht das Team-Soll.
- 331 zusammengefasste Zeitblöcke und 13 minutengenaue Beginn-/Endangaben übernommen.
- Excel zählt Einträge mit BZ oder X am Anfang als Betreuung, VZ als Vorbereitung und PZ als Pause.
- Insbesondere zählt Excel die 124 Zellen mit der Beschriftung **BZ/VZ vollständig als BZ**. Eine innere Trennzeit ist dort nicht gespeichert. Diese Einträge sind deshalb als BZ-Blöcke mit der Bezeichnung „aus Excel: BZ/VZ“ übernommen. Es wird keine Aufteilung erfunden. Sie lassen sich bei Bedarf in der HTML-Version in geteilte BZ/VZ-Blöcke ändern und mit einer eigenen Trennzeit versehen.
- Die 19 Personen ergeben zusammen vier Minuten weniger Ist als Soll. Die Abweichung liegt bei der Person im Excel-Blatt „Arbeiter.“: Soll 26:06, Ist 26:02.
- Die Excel-Besetzungsformel zählt BZ nur in C:O und übersieht entsprechende Einträge ab Person 14. Die HTML-Besetzung zählt alle angelegten Personen.

## Validierung

Playwright mit Chromium wurde verwendet, da kein Browser-Plugin verfügbar ist.

- Unabhängige Auswertung der Excel-Eingaben: alle 300 Tageswerte (20 Spalten × 5 Tage × BZ/VZ/Pause) stimmen mit den gespeicherten Excel-Ergebnissen überein.
- Nach der Übernahme stimmen alle 19 Vertrags-Sollwerte, Wochenwerte und 285 Tageswerte der belegten Personen in der HTML-Version mit dieser Auswertung überein.
- Team-Saldo nach Ausschluss des leeren Reserveplatzes: −0:04.
- Alle 280 Viertelstunden der Teambesetzung wurden unabhängig über jede einzelne Minute geprüft, einschließlich Wechseln außerhalb des Rasters und Personen ab Spalte P.
- Prozent-/Vertragsstunden-Eingabe, BZ/VZ-Trennlinie per Ziehen, genaue Endzeit, Tastatur, Bezeichnungen mit Sonderzeichen, Browser-Speicherung, JSON-Sicherung mit 331 Blöcken und Druck aller 19 Personen geprüft.
- Außerdem Verschieben zwischen Tagen, Beginn-/Endänderung, Überlappungsabweisung und Touch-Gesten für Verschieben, Trennlinie und Verlängern geprüft. Keine externen Ressourcen nötig; lokale Bearbeitung bei abgeschaltetem Netzwerk geprüft.
- Aktuelle Desktopansicht mit Viewport 1467 × 1072 und Mobilansicht 390 × 844 geprüft. Kein Überlauf der gesamten Seite und keine JavaScript-Fehler.

Das direkte Öffnen über `file://` ließ sich wegen der Browserrichtlinie der Testumgebung nicht prüfen. Funktion und Speicherung wurden über einen lokalen HTTP-Server geprüft. Bei gesperrter Browser-Speicherung gibt die Anwendung einen Hinweis; die Dateisicherung bleibt verfügbar.

## Visueller Abgleich

Entwurf: `/workspace/generated_images/exec-76927130-47d9-4d4e-8b64-edd114110c21.png`. Entwurf und aktuelle vollständige Desktop-/Mobil-Screenshots wurden mit `view_image` verglichen. Die Bildschirmaufnahmen entstanden mit Playwright bei nativer Entwurfsbreite 1467 und Viewport-Höhe 1072; die vollständige Seite ist höher.

| Vergleichspunkt | Ergebnis / Anpassung |
|---|---|
| Aufbau | Personenleiste, Einstellungen, fünf Kalenderspalten und Wochenübersicht wie im Entwurf. |
| Farben | Weißer Hintergrund, dunkelblaue Schrift, türkisfarbene BZ- und violette VZ-Blöcke übernommen. |
| Typografie | Systemschrift mit durchgehenden Überschriften-, Bedien- und Tabellenstilen. |
| Blöcke | Farbige Teilflächen und Ziehgriffe; echte BZ-/VZ-Zeiten lesbar statt statischer Beispieldaten. |
| Abstände | Absichtlich 54 Pixel je Stunde für die Bedienbarkeit der Trennlinie. Dadurch höher als der Bildentwurf. |
| Texte | Titel, Untertitel, Tage und Aktionen erhalten. Bestätigte 39-Stunden-Basis ersetzt die alte 29-Stunden-Angabe. Pause, Vertragsstunden, Beschriftung, Bilanzen und Besetzung sind funktionale Ergänzungen aus den Nutzeranforderungen bzw. der Excel-Auswertung. Fiktive Datumsangaben entfallen bei der Wochenvorlage. |
| Tabellen | Separate BZ-/VZ-Sollwerte und Teamsumme ergänzt; umfangreiche Details aufklappbar, auf Mobilgeräten gezielt seitlich scrollbar. |
| Mobil | Einstellungen umbrechen, Personenliste und Kalender seitlich bedienbar, kein Seitenüberlauf. |

Der Textabgleich ergab nur die dokumentierten Funktionsanpassungen. Die Umsetzung wurde gegen den Entwurf unter Berücksichtigung dieser Änderungen visuell geprüft; keine offenen Darstellungsfehler gefunden. Temporäre Screenshots und Prüfdateien wurden nach der Prüfung entfernt.

## Ergänzende Prüfung: keine verlorenen Minuten

Alle 2.341 möglichen Vertragsminuten von 0:00 bis 39:00 wurden jeweils durch drei JSON-Speicher-/Ladezyklen geprüft. Keine Vertragsminute ging verloren; BZ-Soll und VZ-Soll ergeben zusammen immer das Gesamt-Soll. Alte Sicherungen ohne das neue Vertragsminuten-Feld bleiben kompatibel.

08:31–09:03 ergibt exakt 32 Minuten; bei Trennlinie 08:47 sind es 16 Minuten BZ und 16 Minuten VZ. 137 einzelne Ein-Minuten-Blöcke ergeben exakt 137 Minuten. Ein-Minuten-Änderungen mit Maus und Tastatur, Unterkante und innerer Trennlinie, freies Anlegen um 08:37 sowie Sicherung und Wiederherstellung wurden im Browser geprüft. Alle 19 übernommenen Verträge und alle 331 Excel-Zeitblöcke behalten ihre Minuten. Der bestehende Team-Saldo von −0:04 bleibt als tatsächliche Abweichung erhalten.
