# Dienstplan – aktuelle HTML-Version

ZIP entpacken und **Wochenplan.html** öffnen. Die Anwendung enthält die hochgeladene Excel-Vorlage und den ausgefüllten Dienstplan. Sie benötigt keine Installation, keinen Account und keine externen Bibliotheken aus dem Internet.

Vorhandene Browserdaten bleiben beim Öffnen erhalten. **Mehr → Ausgefüllten Plan laden** stellt den ursprünglich hochgeladenen Excel-Stand nach einer Rückfrage wieder her. Eigene Änderungen vorher mit **Sicherung** als JSON sichern. **Mehr → Datei öffnen** stellt eine solche JSON-Sicherung wieder her.

## Einfacher Einstieg

Der Tagesplan ist die Startansicht und steht direkt unter den Werkzeugen. Es gibt keine zusätzliche Namensleiste links. Berechnungen, Wochenstunden, Vorlagenvergleich und Hilfe sind eingeklappt und bei Bedarf verfügbar.

1. Oben **Montag bis Freitag** wählen. Alle Mitarbeitenden stehen nebeneinander wie im Excel-Tagesblatt.
2. **BZ**, **VZ**, **BZ/VZ** oder **Pause** wählen.
3. In einer freien Personenspalte den gewünschten Zeitraum aufziehen. Neue Zeiträume werden dabei an den Viertelstunden ausgerichtet. Aufziehen funktioniert nach unten und nach oben. Überschneidungen werden vollständig abgelehnt.
4. Für exakte Minuten eine freie Stelle oder einen bestehenden Block anklicken und Beginn/Ende eingeben. Ein Ende **16:03** bleibt erhalten. Vorhandene Blöcke lassen sich weiterhin minutengenau verschieben, verlängern und kürzen.

Rechts im Tagesplan stehen die gleichzeitigen **BZ+VZ-, BZ- und VZ-Besetzungen** für alle Mitarbeitenden. Bei einem Wechsel innerhalb der Viertelstunde erscheint zum Beispiel **2–3**. Diese Spalten und die linke Zeitachse bleiben beim seitlichen Scrollen sichtbar. Die Namen bleiben beim vertikalen Scrollen im Plan sichtbar. Bei gekürzten Namen zeigt der Mauszeiger den vollständigen Namen; ein Klick öffnet die Personendaten.

**Mitarbeitende** öffnet die Namens- und Vertragsverwaltung. Dort eine Person wählen und **Person entfernen** drücken. Nach der Rückfrage werden ihre Zeitblöcke und Stunden aus dem aktuellen Plan entfernt. **Rückgängig** stellt die Person samt Vertragsstunden und allen Zeiten wieder her. Auch die letzte Person kann entfernt werden; der leere Plan bietet **Person hinzufügen** und **Rückgängig**. Die mitgelieferte Excel-Vorlage bleibt als wieder ladbarer Ausgangsplan enthalten.

**Sicherung** speichert den Plan als JSON. **Excel exportieren** erstellt den ausgefüllten Excel-Plan. Datei öffnen, Drucken und das Wiederherstellen des Ausgangsplans stehen unter **Mehr**.

## Drei Ansichten

- **Wochenübersicht · alle:** Mitarbeitende als Zeilen, Montag bis Freitag als Spalten. Die vollständigen Uhrzeiten stehen direkt in den Tagesfeldern. Auf einen Zeitraum klicken, um ihn zu bearbeiten; **+ Zeitraum** fügt Zeiten für genau diese Person und diesen Tag hinzu. Zeiträume lassen sich in andere Tagesfelder ziehen. Dabei bleiben ihre Anfangs- und Endzeiten erhalten.
- **Tagesplan · alle (Startansicht):** Aufbau ähnlich den Tagesblättern in Excel. Wochentag wählen, Mitarbeitende nebeneinander, Zeitachse von 06:00 bis 20:00 in 15-Minuten-Schritten.
- **Personenwoche:** Eine ausgewählte Person mit Montag bis Freitag nebeneinander im Zeitraster.

Die Ansichten lassen sich über die Auswahl rechts neben den Wochentagen wechseln. Die Tagestasten kehren immer zum gemeinsamen Tagesplan zurück. In der Wochenübersicht bleiben Personen- und Tagesüberschriften beim Scrollen sichtbar. Auf kleinen Bildschirmen ist die Tabelle seitlich scrollbar.

## Zeiten und Farben

- BZ: Betreuung, türkis.
- VZ: Vorbereitung, violett.
- **BZ/VZ: orange und vollständig als BZ gerechnet, genau wie in der gelieferten Excel-Datei. Eine zusätzliche Trennzeit gibt es nicht.**
- Pause: grau, zählt nicht zur Arbeitszeit.

Die Schaltflächen **BZ**, **VZ**, **BZ/VZ** und **Pause** wählen die Art für das Aufziehen neuer Zeiträume. Alternativ lassen sich die Schaltflächen weiterhin direkt auf einen Tag bzw. eine Person ziehen; ein solcher neuer Baustein beginnt mit **15 Minuten**. In der tabellarischen Wochenübersicht öffnet **+ Zeitraum** die genaue Eingabe für das gewählte Tagesfeld.

Im Zeitraster bewegt das Ziehen am Textbereich den ganzen Block. Die mittleren Griffe oben bzw. unten ändern Beginn bzw. Ende. Ein Klick auf einen Block öffnet die genaue Eingabe. In der tabellarischen Wochenübersicht öffnet ein Klick ebenfalls die genaue Eingabe; dort verschiebt Ziehen die unveränderten Uhrzeiten zu einem anderen Tag bzw. einer anderen Person.

Die 15-Minuten-Linien sind eine optische Orientierung. **16:03 bleibt 16:03** und wird auch so angezeigt. Ziehen und Pfeiltasten arbeiten in 1-Minuten-Schritten; Umschalt + Pfeil auf/ab arbeitet in 15-Minuten-Schritten. Enter öffnet die Bearbeitung. Kurze Blöcke zeigen Art und Endzeit; die vollständigen Zeiten stehen in der Wochenübersicht und im Bearbeitungsdialog.

## Markieren, kopieren, einfügen

Die Schaltflächen zum Kopieren und Löschen erscheinen, sobald Blöcke markiert sind. **Einfügen** erscheint nach dem Kopieren. **Wiederholen** erscheint, wenn ein rückgängig gemachter Schritt verfügbar ist.

1. **Markieren** einschalten und Zeitblöcke anklicken. Alternativ Strg/Cmd + Klick für einzelne Blöcke; Umschalt + Klick wählt einen Bereich. Strg/Cmd + A markiert im Markieren-Modus alle Blöcke der aktuellen Ansicht.
2. **Kopieren** oder Strg/Cmd + C drücken.
3. **Einfügen** oder Strg/Cmd + V drücken und das Zielfeld anklicken.

In der Wochenübersicht bleiben die Uhrzeiten beim Einfügen erhalten. Bei einer Auswahl über mehrere Personen oder Tage werden die relativen Abstände übernommen. Im Zeitraster wird die früheste kopierte Anfangszeit an der angeklickten Minute ausgerichtet; Dauer und Lücken bleiben erhalten.

Die Block-Zwischenablage gilt innerhalb der laufenden Anwendung. Sie ist kein allgemeiner Import beliebiger Excel-Zellen und bleibt nach Neuladen nicht erhalten. Innerhalb von Text- und Zeitfeldern funktionieren die normalen Kopier-/Einfügetasten des Browsers.

Eine Einfügeaktion wird vollständig abgelehnt, wenn sie Überschneidungen erzeugt oder nicht in die vorhandenen Personen/Wochentage passt. Es wird nichts teilweise eingefügt oder abgeschnitten. **Auswahl löschen** entfernt nach einer Rückfrage nur die markierten Blöcke. **Auswahl aufheben** beendet die Markierung.

**Rückgängig** und **Wiederholen** bzw. Strg/Cmd + Z und Strg/Cmd + Umschalt + Z / Y verwalten bis zu 30 Bearbeitungsschritte im laufenden Browserfenster. Das umfasst auch Einfügen und Löschen. Die Bearbeitungshistorie bleibt nach Neuladen nicht erhalten; die gespeicherten Plandaten bleiben erhalten.

## Rechenregeln

Die bestätigte Vollzeitbasis beträgt **39 Wochenstunden**, davon **31 Stunden BZ und 8 Stunden VZ**.

| Beschäftigung | Gesamt-Soll | BZ-Soll | VZ-Soll |
|---|---|---|---|
| 100 % | 39:00 | 31:00 | 8:00 |
| 75 % | 29:15 | 23:15 | 6:00 |
| 50 % | 19:30 | 15:30 | 4:00 |
| 25 % | 9:45 | 7:45 | 2:00 |

Prozentwert oder Vertragszeit als Stunden:Minuten, z. B. **36:18**, eingeben. Die Vertragszeit wird als ganze Minutenzahl gespeichert, nicht aus einer gerundeten Prozentanzeige zurückgerechnet. Bei Prozenteingabe wird das Gesamt-Soll auf die nächste Minute gerundet. BZ-Soll wird auf die nächste Minute gerundet, VZ-Soll bekommt den Rest. Beide ergeben zusammen immer genau das Gesamt-Soll.

Ist gesamt = BZ + BZ/VZ + VZ. Pausen werden separat summiert. Differenz = Ist minus Soll. Die tatsächlichen BZ-/VZ-Anteile werden nicht automatisch auf die Sollquote gezwungen.

Die Wochenbilanz zeigt Soll, Ist und Differenz für BZ, VZ und Gesamt. Die Tagesbilanz zeigt die Arbeits- und Pausenzeiten pro Tag. Die Anwesenheit dort ist die Summe der eingetragenen Zeiträume einschließlich Pausen; freie Lücken werden nicht hinzugerechnet. Ein tägliches Soll wird nicht erfunden, da die Excel-Vorlage Wochen-Sollwerte vorgibt.

Die Team-Besetzung zählt alle Personen. Bei minutengenauen Wechseln innerhalb einer Viertelstunde zeigt sie die kleinste bis größte gleichzeitige Besetzung, etwa **2–3**. Pausen zählen nicht dazu.

## Vergleich mit der Excel-Vorlage

**Zeiten mit der ursprünglichen Excel-Vorlage vergleichen** zeigt für gleichnamige Personen die abweichenden Tage, geänderten Minuten und Unterschiede bei den Vertragsstunden. Die Zuordnung erfolgt anhand des Namens. Wenn ein Name nicht zugeordnet werden kann, wird das ausdrücklich angezeigt.

In der Wochenübersicht werden zusätzliche oder fehlende Arbeitsminuten gegenüber der Vorlage direkt am jeweiligen Tag markiert. Bewusst geänderte Pläne dürfen natürlich von der Vorlage abweichen.

Der mitgelieferte ausgefüllte Dienstplan enthält **19 Personen und 331 Zeitblöcke**, davon 30 BZ/VZ-Blöcke. Der unbenannte Reserveplatz 20 wird nicht als beschäftigte Person gezählt. Der Originalplan liegt bereits vier Minuten unter dem Gesamt-Soll: Im Blatt „Arbeiter.“ stehen 26:02 Ist bei 26:06 Soll. Diese Abweichung wird nicht künstlich ausgeglichen.

## Excel-Export in die ursprüngliche Vorlage

**Excel exportieren** lädt eine neue XLSX-Datei herunter. Der Export verwendet die hochgeladene Datei **2027 Entwurf Dienstplan_GTS 20MA-15min.xlsx** als Vorlage und trägt die aktuellen Namen, Vertragsstunden und Zeiten in deren Tages- und Personenblätter ein. Die Quelldatei selbst wird nicht verändert.

Layout, Zellformatierungen, Druckausrichtung und verbundene Zellen der Originalblätter bleiben erhalten. Die Personentabs werden passend benannt. Ein unbesetzter Reserveplatz hat im Export null Vertragsstunden.

Wechsel innerhalb einer Viertelstunde lassen sich in einem einzigen Rasterfeld nicht vollständig berechnen. Deshalb enthält der Export zusätzlich:

- **Planzeiten:** Exakte Anfangs-/Endzeiten und ganze Minuten jedes Zeitraums; BZ/VZ steht rechnerisch als BZ und bleibt in der Bezeichnung erkennbar.
- **Auswertung:** Soll, Ist und Differenzen für BZ, VZ und Gesamt, einschließlich Teamsumme.
- **_Besetzung:** Ausgeblendetes Rechenblatt für minutengenaue Besetzung und die Min-/Max-Werte des ursprünglichen Tagesrasters.

Die Summen in den Originalblättern werden aus den exakten Planzeiten berechnet und sind bereits mit Ergebnissen vorbelegt. Excel berechnet sie beim Öffnen neu. Negative Differenzen werden lesbar als etwa **-0:04** dargestellt.

Das gedruckte Tagesraster ist die **Exportansicht**. Für Änderungen den HTML-Plan bearbeiten und neu exportieren. Alternativ lassen sich Beginn und Ende im Excel-Blatt **Planzeiten** ändern; dann rechnen Summen und Besetzung neu, während die Rasterbeschriftungen die ursprüngliche Exportansicht bleiben. Direkte Änderungen der Beschriftungen im Tagesraster verändern die maßgeblichen Detailzeiten nicht. Dieser Hinweis steht auch oben in den Tagesblättern.

**Mehr → Drucken** im HTML-Plan enthält die Bilanz und die Zeitpläne aller angelegten Personen. Im Druckdialog kann PDF ausgewählt werden. Die Anwendung ist eine wiederverwendbare Montag-bis-Freitag-Vorlage; unterschiedliche Kalenderwochen werden über eigene JSON-Sicherungen verwaltet.

## Durchgeführte Prüfungen

Aktuelle Vereinfachung der Oberfläche:

- Tagesplan als Startansicht, direkte Montag-bis-Freitag-Auswahl, alle 19 Personenspalten, drei sichtbare Besetzungsspalten und eingeklappte Nebenbereiche im Browser geprüft.
- Alle 56 Besetzungszeiträume eines Originaltages gegen unabhängig minutengenau gezählte BZ-/VZ-Werte geprüft, einschließlich aller Min-/Max-Bereiche.
- Neue Zeiträume nach unten und oben aufgezogen, Kollisionsfälle ohne Teiländerungen abgewiesen, 08:31–09:03 exakt als 32 Minuten gespeichert und Endzeit 16:03 sichtbar erhalten.
- Verschieben zwischen Personen, minutengenaue Tastaturbewegung, Verlängern um zehn Minuten, Palette ziehen, Kopieren/Einfügen und Rückgängig/Wiederholen nach der Vereinfachung erneut geprüft.
- Entfernen einer Person nach Bestätigung, Abbrechen ohne Änderungen, vollständiges Wiederherstellen mit Zeiten/Vertragsstunden und aktualisierte Team-Besetzung geprüft. Auch letzte Person entfernen, leeren Plan speichern/neu laden und neu anfangen geprüft.
- Excel nach Entfernen einer mittleren Person geöffnet: Reihenfolge/Namen, freie Reserveplätze, Vertragsminuten und Arbeitszeiten der verbleibenden Personen geprüft.
- Desktop (1600 Pixel) und Handy (390 Pixel) visuell geprüft, ohne Seitenüberlauf oder JavaScript-Fehler. Die Druckfunktion öffnet die Team-Bilanz vor dem Drucken und stellt deren vorherigen Zustand anschließend wieder her.

Vorherige vollständige Rechen- und Exportprüfung:

- 19 Verträge, 331 Zeitblöcke und die ursprünglichen BZ-/VZ-/Pausensummen wurden unabhängig mit den Excel-Eingaben und gespeicherten Ergebnissen verglichen.
- Alle 380 Tages-Gesamt-/BZ-/VZ-/Pausenwerte der belegten Personenspalten und 114 Vertrags-/Wochenwerte stimmen im Export mit der Vorlage überein.
- Alle ursprünglichen BZ/VZ-Rastereinträge bleiben im Excel-Export als solche erkennbar; die Kategorie zählt vollständig als BZ. Keine Aufteilungszeit erforderlich.
- Excel-Exporte wurden mit openpyxl gelesen, die XML-Struktur und die erhaltenen Zellstile, verbundenen Zellen sowie Druckausrichtungen geprüft. Anschließend wurden die Dateien mit LibreOffice tatsächlich neu berechnet: keine Formelfehler, unveränderte Tages-/Wochenwerte, Detailminuten, Differenzen und alle 280 Besetzungszeiträume.
- Alle 2.341 möglichen Vertragsminuten von 0:00 bis 39:00 wurden über Speicher-/Ladezyklen geprüft. BZ-Soll plus VZ-Soll bleibt exakt das Gesamt-Soll.
- 08:31–09:03 ergibt exakt 32 Minuten. Ein Ende 16:03 wird eingegeben, angezeigt und exportiert, ohne es auf das Raster zu runden.
- Ein absichtlich um 28 Minuten verlängerter Montag wurde im Vorlagenvergleich exakt als Änderung 17:00–17:28 erkannt.
- Wochenübersicht mit 19 Personen und 95 Tagesfeldern, Bearbeitung pro Tag, Wechsel zwischen Ansichten, Bausteine aus der Palette, Verschieben zwischen Personen/Tagen, minutengenaues Verlängern/Kürzen und Abfangen von Überschneidungen im Browser geprüft.
- Mehrfach- und Bereichsauswahl, Kopieren/Einfügen, Tastenkürzel, ausgewähltes Löschen sowie Rückgängig/Wiederholen geprüft. 32 + 35 Minuten mit 7 Minuten Lücke bleiben auch beim Einfügen ab 16:03 exakt erhalten. Kollisionsfälle verändern den Plan nicht teilweise.
- Desktop und Mobilansicht geprüft: kein Seitenüberlauf, normale Texteingaben bleiben bedienbar, keine JavaScript-Fehler.

Die Browserprüfung erfolgte mit Playwright/Chromium, weil kein Browser-Plugin verfügbar war. Aktuelle Bildschirmaufnahmen der Wochen- und Tagesansichten wurden visuell angesehen. Geprüft wurden Tabellenaufbau, Beschriftung, Lesbarkeit der Uhrzeiten, unterschiedliche Kategorienfarben, Abstände, Scrollverhalten und die Darstellung genauer Endzeiten. Temporäre Prüfdateien werden nicht mitgeliefert.

Das direkte Öffnen über file:// war in der Testumgebung durch die Browserrichtlinie gesperrt; die Funktion wurde über einen lokalen HTTP-Server getestet. Die ausgelieferte Datei enthält alle benötigten Ressourcen. Bei gesperrter Browser-Speicherung gibt die Anwendung einen Hinweis; JSON-Sicherungen bleiben verfügbar.

Die eingebettete ZIP-Bibliothek ist fflate 0.8.2. Ihr npm-Paket wurde beim Einrichten per SHA-512-Integrität geprüft. Die Lizenz liegt als **fflate-LICENSE.txt** bei. Im Betrieb werden keine externen Bibliotheken nachgeladen.
